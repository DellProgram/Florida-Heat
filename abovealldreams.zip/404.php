<?php get_header(); ?>
<div class="container" style="text-align: center; padding: 100px 0;">
    <h1 class="page-title">404 - Page Not Found</h1>
    <p>It looks like nothing was found at this location. Maybe try a search?</p>
    <?php get_search_form(); ?>
</div>
<?php get_footer(); ?>