document.addEventListener('DOMContentLoaded', () => {

    // --- GLOBAL SCRIPTS (RUN ON EVERY PAGE) ---

    // 1. HEADER SCROLL EFFECT
    const header = document.querySelector('.main-header');
    if (header) {
        window.addEventListener('scroll', () => {
            header.classList.toggle('scrolled', window.scrollY > 50);
        });
    }

    // 2. MOBILE NAVIGATION
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
        // Close menu when a nav link is clicked
        navMenu.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
            });
        });
    }

    // 3. CONTINUOUS FIRE EMBER ANIMATION
    const emberContainer = document.getElementById('fire-ember-container');

    function createEmber() {
        if (!emberContainer) return;

        const ember = document.createElement('div');
        ember.classList.add('ember');

        const startX = Math.random() * 100;
        const xEnd = (Math.random() * 200) - 100;
        const riseDuration = (Math.random() * 10) + 8;
        const size = (Math.random() * 6) + 2;

        ember.style.left = `${startX}vw`;
        ember.style.width = `${size}px`;
        ember.style.height = `${size}px`;
        ember.style.setProperty('--x-end', `${xEnd}px`);
        ember.style.animationDuration = `${riseDuration}s`;
        ember.style.opacity = Math.random() * 0.6 + 0.2;

        emberContainer.appendChild(ember);

        ember.addEventListener('animationend', () => {
            ember.remove();
            createEmber();
        });
    }

    if (emberContainer) {
        const initialEmberCount = 40;
        for (let i = 0; i < initialEmberCount; i++) {
            setTimeout(createEmber, Math.random() * 5000);
        }
    }


    // --- PRODUCTS PAGE ONLY SCRIPTS (WooCommerce handles cart/checkout) ---
    // Remove or significantly modify this block if using WooCommerce.
    // The current Stripe logic will be replaced by WooCommerce's payment gateway.
    // However, some UI elements for the modal might still be useful if you're not fully
    // relying on WooCommerce's cart/checkout pages.

    // If you plan to use WooCommerce for cart/checkout, this entire section for cartModal,
    // addToCartButtons, Stripe initialization, etc., should be removed or commented out.
    // WooCommerce provides its own cart count, add-to-cart buttons, and checkout flow.

    // Example of how you might adapt the cart count if still using a custom icon:
    const cartCountElement = document.getElementById('cart-count');
    if (cartCountElement) {
        // This relies on WooCommerce's global JS object for cart contents.
        // Make sure WooCommerce is active.
        if (typeof wc_add_to_cart_params !== 'undefined') {
            jQuery(document.body).on('added_to_cart', function() {
                // Update cart count on product added to cart
                jQuery.post(wc_add_to_cart_params.ajax_url, {
                    action: 'woocommerce_get_refreshed_fragments'
                }, function(data) {
                    if (data.fragments && data.fragments['span.cart-count']) {
                        const newCount = jQuery(data.fragments['span.cart-count']).text();
                        cartCountElement.textContent = newCount;
                        if (parseInt(newCount) > 0) {
                            cartCountElement.style.display = 'flex';
                        } else {
                            cartCountElement.style.display = 'none';
                        }
                    }
                });
            });
             // Initial cart count on page load
             if (parseInt(cartCountElement.textContent) > 0) {
                cartCountElement.style.display = 'flex';
            } else {
                cartCountElement.style.display = 'none';
            }
        } else {
            // Fallback if WooCommerce is not active or its JS isn't loaded
            console.warn('WooCommerce JavaScript parameters not found. Cart count may not update dynamically.');
            // You might remove this whole products-page-only block if not using WooCommerce.
        }
    }

    // The entire Stripe integration and custom cart modal (cart-modal, checkout-form, etc.)
    // should ideally be replaced by WooCommerce. If you need a custom checkout flow,
    // you would use WooCommerce hooks and potentially Stripe's WooCommerce gateway.

});