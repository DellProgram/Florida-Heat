<?php
/**
 * AAD Hot Sauce Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package AAD_Hot_Sauce_Theme
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function aad_hotsauce_setup() {
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on AAD Hot Sauce Theme, use a find and replace
		* to change 'aad-hotsauce' to the name of your theme in all the template files.
		*/
	load_theme_textdomain( 'aad-hotsauce', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support( 'title-tag' );

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'main-menu' => esc_html__( 'Primary menu', 'aad-hotsauce' ),
		)
	);

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Add theme support for selective refresh for widgets in Customizer.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/custom-logo/
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action( 'after_setup_theme', 'aad_hotsauce_setup' );

/**
 * Enqueue scripts and styles.
 */
function aad_hotsauce_scripts() {
    // Google Fonts
    wp_enqueue_style( 'google-fonts', 'https://fonts.googleapis.com/css2?family=Teko:wght@700&family=Montserrat:wght@400;600;700&family=Cinzel:wght@700&display=swap', array(), null );

	wp_enqueue_style( 'aad-hotsauce-style', get_stylesheet_uri(), array(), _S_VERSION );

    // Enqueue Font Awesome for cart icon if not using SVG directly
    // If you prefer to use the SVG, you can remove this or keep it for future icons.
    // wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css', array(), '6.0.0-beta3' );

    // Enqueue main script
    wp_enqueue_script( 'aad-hotsauce-script', get_template_directory_uri() . '/js/script.js', array('jquery'), _S_VERSION, true );

    // Stripe JS for products page
    if ( is_page_template( 'page-products.php' ) || is_singular( 'product' ) || is_post_type_archive( 'product' ) ) {
        wp_enqueue_script( 'stripe-js', 'https://js.stripe.com/v3/', array(), null, true );
    }
}
add_action( 'wp_enqueue_scripts', 'aad_hotsauce_scripts' );

/**
 * Filter the body class to add page-specific classes for background images and ember colors.
 */
function aad_hotsauce_body_classes( $classes ) {
    if ( is_front_page() || is_page( 'home' ) ) { // Assuming 'home' is your front page
        $classes[] = 'page-home';
    } elseif ( is_page( 'products' ) || is_post_type_archive( 'product' ) || is_singular( 'product' ) ) { // For WooCommerce products
        $classes[] = 'page-products';
    } elseif ( is_page( 'about' ) ) {
        $classes[] = 'page-about';
    } elseif ( is_page( 'contact' ) ) {
        $classes[] = 'page-contact';
    }
    return $classes;
}
add_filter( 'body_class', 'aad_hotsauce_body_classes' );

// Placeholder for Elementor support
function aad_hotsauce_add_elementor_support() {
    add_theme_support( 'elementor' );
}
add_action( 'after_setup_theme', 'aad_hotsauce_add_elementor_support' );

// Ensure full-width layout for Elementor pages
add_action( 'after_setup_theme', 'aad_hotsauce_setup_elementor_full_width' );
function aad_hotsauce_setup_elementor_full_width() {
    add_post_type_support( 'page', 'elementor' );
}