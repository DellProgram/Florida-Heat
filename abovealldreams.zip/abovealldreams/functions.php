<?php
/**
 * Above All Dreams Theme Functions
 *
 * @package AboveAllDreams
 */

// --- Theme Setup ---
function abovealldreams_setup() {
    // Add support for core WordPress features.
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );

    // Add support for WooCommerce.
    add_theme_support( 'woocommerce' );

    // Register navigation menus.
    register_nav_menus( array(
        'primary_menu' => esc_html__( 'Primary Menu', 'abovealldreams' ),
    ) );
}
add_action( 'after_setup_theme', 'abovealldreams_setup' );


// --- Enqueue Scripts and Styles ---
function abovealldreams_scripts() {
    // Enqueue Google Fonts.
    wp_enqueue_style( 'google-fonts', 'https://fonts.googleapis.com/css2?family=Teko:wght@700&family=Montserrat:wght@400;600;700&family=Cinzel:wght@700&display=swap', array(), null );

    // Enqueue the main stylesheet from the original site.
    wp_enqueue_style( 'main-style', get_template_directory_uri() . '/main.css', array(), '1.0.0' );

    // Enqueue the theme's style.css for theme identification (and minor overrides if needed).
    wp_enqueue_style( 'abovealldreams-style', get_stylesheet_uri() );

    // Enqueue the main javascript file from the original site.
    // The 'in_footer' argument is set to true to load it at the bottom of the page.
    wp_enqueue_script( 'main-script', get_template_directory_uri() . '/script.js', array(), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'abovealldreams_scripts' );

// --- WooCommerce Helper Functions (Optional but Recommended) ---

// Ensure cart fragments are refreshed when items are added to the cart via AJAX.
// This will make the WooCommerce cart icon update automatically.
function abovealldreams_woocommerce_cart_link_fragment( $fragments ) {
    ob_start();
    ?>
    <a class="cart-button" href="<?php echo esc_url( wc_get_cart_url() ); ?>" title="<?php esc_attr_e( 'View your shopping cart', 'abovealldreams' ); ?>">
        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 16 16">
            <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 7A.5.5 0 0 1 13 11H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l1.313 6h8.17l1.313-6H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
        </svg>
        <span class="cart-count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
    </a>
    <?php
    $fragments['a.cart-button'] = ob_get_clean();
    return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'abovealldreams_woocommerce_cart_link_fragment' );

?>
